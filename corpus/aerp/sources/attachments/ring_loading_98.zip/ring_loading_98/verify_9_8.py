"""Exact verification of the lower bound C >= 9/8 for the ring loading constant.
Pure Python, exact rational arithmetic, no dependencies. Runs in a few seconds."""
import itertools
from fractions import Fraction as F

# certificate: m = 14 pairs (u_i, v_i), all values divided by 16
P = [(6, 2), (3, 13), (12, 2), (8, 8), (2, 12), (11, 5), (4, 4),
     (5, 11), (12, 2), (8, 8), (2, 12), (13, 3), (2, 6), (12, 4)]
u = [F(a, 16) for a, b in P]; v = [F(b, 16) for a, b in P]; m = len(P)
assert all(x >= 0 for x in u + v) and all(a + b <= 1 for a, b in zip(u, v))

def worst(z, ks):                      # max_k |sum_{i<=k} z_i - sum_{i>k} z_i|
    T, S, w = sum(z), F(0), F(0)
    pre = [F(0)]
    for x in z: S += x; pre.append(S)
    return max(abs(2 * pre[k] - T) for k in ks)

choices = list(itertools.product(*[(v[i], -u[i]) for i in range(m)]))
alpha = min(worst(z, range(1, m + 1)) for z in choices)          # Schrijver-Seymour-Winkler, k = 1..m
print("alpha (k = 1..m)            =", alpha, "=", float(alpha))

# DeepMind notebook convention uses k = 1..m-1; pad with a (0,0) pair at both ends
zp = [(F(0), F(0))] + list(zip(u, v)) + [(F(0), F(0))]
up, vp = [a for a, b in zp], [b for a, b in zp]
alpha_dm = min(worst(z, range(1, len(zp))) for z in itertools.product(*[(vp[i], -up[i]) for i in range(len(zp))]))
print("alpha (padded, k = 1..m-1)  =", alpha_dm)
print("beats 47/42:", alpha > F(47, 42) and alpha_dm > F(47, 42))
