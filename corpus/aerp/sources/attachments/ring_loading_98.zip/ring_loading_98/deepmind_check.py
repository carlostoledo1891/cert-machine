"""DeepMind's own verification function, copied verbatim from their notebook (compute_alpha_exact)."""
import itertools, sys, numpy as np
def validate_input(u, v):
  if len(u) != len(v): raise ValueError('len')
  if not all(x >= 0 for x in u) or not all(x >= 0 for x in v): raise ValueError('neg')
  if not all(ui + vi <= 1.000001 for ui, vi in zip(u, v)): raise ValueError('sum')
def compute_alpha_exact(u, v):
  validate_input(u, v)
  m = len(u)
  best_alpha = float('inf')
  z_choices = [(vi, -ui) for ui, vi in zip(u, v)]
  for z in itertools.product(*z_choices):
    max_alpha_for_z = 0
    if m > 1:
      max_alpha_for_z = max(abs(sum(z[:k]) - sum(z[k:])) for k in range(1, m))
    best_alpha = min(best_alpha, max_alpha_for_z)
  return best_alpha
d = np.loadtxt(sys.argv[1]); D = float(sys.argv[2])
u = [float(x) / D for x in d[:, 0]]; v = [float(x) / D for x in d[:, 1]]
a = compute_alpha_exact(u, v)
print(f"DeepMind compute_alpha_exact = {a:.10f}  (47/42 = {47/42:.10f})  beats record: {a > 47/42 + 1e-12}")
