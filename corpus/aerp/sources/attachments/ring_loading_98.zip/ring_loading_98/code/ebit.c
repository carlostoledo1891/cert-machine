/* Bitset escape measure for the CLASSIC definition.
   E(A) = number of states (y, k, h) lying on at least one pattern with value <= A
        = sum over y of popcount(forward_reachable & backward_coreachable).
   E(A) == 0  <=>  alpha > A.   'early' = 1: return 1 as soon as any valid pattern exists (decision). */
#include <stdint.h>
#include <string.h>
#define MW 64                     /* up to 4096 bits per window */
static inline int iabs(int a) { return a < 0 ? -a : a; }
typedef struct { uint64_t w[MW]; } bs;
static int NW;
static inline void bs_clear(bs *b) { memset(b->w, 0, NW * 8); }
static inline void bs_or_shift(bs *dst, const bs *src, int s, int W) {   /* dst |= src shifted by s (index+s), clipped to [0,W) */
    if (s >= W || s <= -W) return;
    if (s >= 0) {
        int ws = s >> 6, bsh = s & 63;
        for (int i = NW - 1; i >= ws; i--) {
            uint64_t x = src->w[i - ws] << bsh;
            if (bsh && i - ws - 1 >= 0) x |= src->w[i - ws - 1] >> (64 - bsh);
            dst->w[i] |= x;
        }
    } else {
        s = -s; int ws = s >> 6, bsh = s & 63;
        for (int i = 0; i + ws < NW; i++) {
            uint64_t x = src->w[i + ws] >> bsh;
            if (bsh && i + ws + 1 < NW) x |= src->w[i + ws + 1] << (64 - bsh);
            dst->w[i] |= x;
        }
    }
    int r = W & 63; if (r) dst->w[(W - 1) >> 6] &= (~0ULL) >> (64 - r);
    for (int i = ((W + 63) >> 6); i < NW; i++) dst->w[i] = 0;
}
double escape(int m, const int *u, const int *v, int A, int early) {
    static bs F[130], B;
    double tot = 0;
    for (int y = -A; y <= A; y++) {                         /* classic: |y| <= A  (k = 0 and k = m terms) */
        int lo = (y - A + 1) >> 1;  while (2 * lo - y < -A) lo++; while (2 * (lo - 1) - y >= -A) lo--;
        int hi = (y + A) >> 1;      while (2 * hi - y > A) hi--;  while (2 * (hi + 1) - y <= A) hi++;
        int W = hi - lo + 1; if (W <= 0) continue;
        NW = (W + 63) >> 6; if (NW > MW) return -1;
        if (0 < lo || 0 > hi || y < lo || y > hi) continue;  /* p(0)=0 and p(m)=y must be inside the window */
        bs_clear(&F[0]); F[0].w[(0 - lo) >> 6] |= 1ULL << ((0 - lo) & 63);
        int dead = 0;
        for (int k = 1; k <= m; k++) {
            bs_clear(&F[k]); bs_or_shift(&F[k], &F[k - 1], v[k - 1], W); bs_or_shift(&F[k], &F[k - 1], -u[k - 1], W);
            int any = 0; for (int i = 0; i < NW; i++) if (F[k].w[i]) { any = 1; break; }
            if (!any) { dead = 1; break; }
        }
        if (dead) continue;
        int iy = y - lo;
        if (!((F[m].w[iy >> 6] >> (iy & 63)) & 1)) continue;
        if (early) return 1;
        /* backward pass: states that can still reach y */
        bs_clear(&B); B.w[iy >> 6] |= 1ULL << (iy & 63);
        for (int k = m; k >= 0; k--) {
            for (int i = 0; i < NW; i++) tot += __builtin_popcountll(F[k].w[i] & B.w[i]);
            if (k == 0) break;
            bs nb; bs_clear(&nb);
            bs_or_shift(&nb, &B, -v[k - 1], W); bs_or_shift(&nb, &B, u[k - 1], W);
            for (int i = 0; i < NW; i++) nb.w[i] &= F[k - 1].w[i];
            B = nb;
        }
    }
    return tot;
}
