/* Exact check of an integer instance: python-free, independent of the search code.
   usage: ./check FILE D        (FILE: one pair "u v" per line, real instance = values / D)
   prints alpha for the classic convention (k = 1..m) and the notebook convention (k = 1..m-1),
   each computed twice: by the dynamic program and by brute force over all 2^m sign choices. */
#include <stdio.h>
int alpha_dp(int m, const int *u, const int *v, int def, int *best_y);
int alpha_brute(int m, const int *u, const int *v, int def);
int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: %s FILE D\n", argv[0]); return 1; }
    FILE *f = fopen(argv[1], "r"); int D = 0; sscanf(argv[2], "%d", &D);
    if (!f || D <= 0) { fprintf(stderr, "cannot read input\n"); return 1; }
    int u[64], v[64], m = 0;
    while (m < 64 && fscanf(f, "%d %d", &u[m], &v[m]) == 2) {
        if (u[m] < 0 || v[m] < 0 || u[m] + v[m] > D) { fprintf(stderr, "invalid pair %d\n", m + 1); return 1; }
        m++;
    }
    printf("m = %d, D = %d\n", m, D);
    for (int def = 1; def >= 0; def--) {
        int a = alpha_dp(m, u, v, def, 0), b = m <= 30 ? alpha_brute(m, u, v, def) : -1;
        printf("%-28s DP: %d/%d   brute force: %d/%d\n",
               def ? "classic (k = 1..m):" : "notebook (k = 1..m-1):", a, D, b, D);
    }
    return 0;
}
