#!/bin/bash
# Endless cycle: structured search (ssa) on N cores for TL seconds, then continuous polishing of every result.
# Start:  nohup ./cycle.sh > cycle.log 2>&1 &        Stop:  pkill -f cycle.sh; pkill -x ssa
cd "$(dirname "$0")"
N=${N:-11}; TL=${TL:-1800}; r=${R0:-1}
ms=(15 17 17 19 19 19 21 21 21 23 23 17 19 21 23 15)
while true; do
  echo "=== cycle $r started $(date +%H:%M), $N procs x ${TL}s"
  for i in $(seq 0 $((N-1))); do
    m=${ms[$i]}; s=$((1000*r + i + 7))
    TL=$TL ./ssa 84 $m $s > cyc_r${r}_m${m}_s${s}.txt 2>&1 &
  done
  wait
  python3 polish.py cyc_r${r}_*.txt >> polish.log 2>&1
  echo "=== cycle $r finished $(date +%H:%M); best so far:"
  grep -ho 'exact [0-9/]*' polish.log | sort -t' ' -k2 | uniq -c | tail -3
  r=$((r+1))
done
