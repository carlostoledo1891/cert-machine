/* Exact alpha for INTEGER instances (0 <= u_i, v_i; u_i + v_i <= D):
   pattern p(0)=0, p(k)=p(k-1)+z_k (z_k in {v_k,-u_k}), y=p(m);  value(z) = max_{k in K} |2p(k)-y|
   def 0 (DeepMind code): K = 1..m-1      def 1 (Schrijver-Seymour-Winkler/Skutella): K = 0..m
   alpha = min_z value(z).  DP over heights inside the window |2h-y| < best, for every candidate y. */
#include <stdlib.h>
#include <string.h>
#include <limits.h>
static inline int iabs(int a) { return a < 0 ? -a : a; }
static inline int imax(int a, int b) { return a > b ? a : b; }

/* returns min(alpha, best) where best is a strict upper cutoff: only values < best are searched */
static int alpha_dp_cut(int m, const int *u, const int *v, int def, int best, int *best_y) {
    if (m <= 0) return 0;
    int zmax = 0; for (int i = 0; i < m; i++) zmax = imax(zmax, imax(u[i], v[i]));
    static int *f = 0, *g = 0; static int cap = 0;
    if (cap < 4 * best + 16) { cap = 4 * best + 16; f = realloc(f, cap * sizeof(int)); g = realloc(g, cap * sizeof(int)); }
    /* parity invariant: if every u_i+v_i is even then y = sum z == sum u (mod 2) for every choice */
    int par = -1, allev = 1, su = 0;
    for (int i = 0; i < m; i++) { if ((u[i] + v[i]) & 1) allev = 0; su += u[i]; }
    if (allev) par = su & 1;
    int Y = (def == 1) ? best : best + 2 * zmax + 2;
    for (int y = -Y; y <= Y; y++) {
        if (par >= 0 && ((y & 1) != par)) continue;
        int sd = def == 1 ? iabs(y) : 0;                    /* contribution of k=0 and k=m (def 1) */
        if (sd >= best) continue;
        if (m == 1) {                                       /* no interior points */
            if (v[0] == y || -u[0] == y) { best = sd; if (best_y) *best_y = y; }
            continue;
        }
        /* interior heights: |2h - y| < best */
        int lo = -(best + iabs(y)), hi = best + iabs(y);
        while (iabs(2 * lo - y) >= best && lo <= hi) lo++;
        while (iabs(2 * hi - y) >= best && hi >= lo) hi--;
        int W = hi - lo + 1; if (W <= 0) continue;
        if (W > cap) { cap = 2 * W; f = realloc(f, cap * sizeof(int)); g = realloc(g, cap * sizeof(int)); }
        for (int i = 0; i < W; i++) f[i] = INT_MAX;
        int hs[2] = { v[0], -u[0] };
        for (int t = 0; t < 2; t++) { int h = hs[t];
            if (h >= lo && h <= hi) { int d = imax(sd, iabs(2 * h - y)); if (d < f[h - lo]) f[h - lo] = d; } }
        for (int k = 2; k <= m - 1; k++) {                  /* interior points p(2)..p(m-1) */
            for (int i = 0; i < W; i++) g[i] = INT_MAX;
            for (int i = 0; i < W; i++) {
                if (f[i] >= best) continue;
                int h = i + lo, a = h + v[k - 1], b = h - u[k - 1];
                if (a >= lo && a <= hi) { int d = imax(f[i], iabs(2 * a - y)); if (d < g[a - lo]) g[a - lo] = d; }
                if (b >= lo && b <= hi) { int d = imax(f[i], iabs(2 * b - y)); if (d < g[b - lo]) g[b - lo] = d; }
            }
            int *tmp = f; f = g; g = tmp;
        }
        for (int i = 0; i < W; i++) {                       /* last step must land exactly on y */
            if (f[i] >= best) continue;
            int h = i + lo;
            if (h + v[m - 1] == y || h - u[m - 1] == y) { best = f[i]; if (best_y) *best_y = y; }
        }
    }
    return best;
}
/* exact alpha: start from a finite cutoff and double it while nothing below it exists */
int alpha_dp(int m, const int *u, const int *v, int def, int *best_y) {
    int smax = 1; for (int i = 0; i < m; i++) smax = imax(smax, u[i] + v[i]);
    for (int cut = 2 * smax + 2;; cut *= 2) {
        int r = alpha_dp_cut(m, u, v, def, cut, best_y);
        if (r < cut) return r;
        if (cut > (1 << 28)) return -1;
    }
}
/* "is alpha >= target?" fast check used in search: returns alpha if < target, else target */
int alpha_dp_below(int m, const int *u, const int *v, int def, int target) {
    return alpha_dp_cut(m, u, v, def, target, 0);
}
/* independent brute force (both definitions) */
int alpha_brute(int m, const int *u, const int *v, int def) {
    int best = INT_MAX;
    for (unsigned long mask = 0; mask < (1UL << m); mask++) {
        int p[64]; p[0] = 0;
        for (int i = 0; i < m; i++) p[i + 1] = p[i] + ((mask >> i & 1) ? v[i] : -u[i]);
        int y = p[m], w = 0, k0 = def ? 0 : 1, k1 = def ? m : m - 1;
        for (int k = k0; k <= k1; k++) w = imax(w, iabs(2 * p[k] - y));
        if (w < best) best = w;
    }
    return best;
}
