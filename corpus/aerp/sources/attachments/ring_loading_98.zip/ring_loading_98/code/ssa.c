/* Structured simulated annealing for the ring loading lower bound (classic definition).
   Structure: m odd, palindromic (pair m-1-i = flip of pair i), full pairs (u+v=D) at odd positions.
   Energy: alpha (exact DP) first, then fewer escape states E(alpha) (plateau breaking).
   usage: TL=sec ssa D m seed [START=file]          prints every new best and the final instance */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <time.h>
int alpha_dp(int m, const int *u, const int *v, int def, int *by);
double escape(int m, const int *u, const int *v, int A, int early);
static int D, m, c;
static double rnd(void) { return rand() / (RAND_MAX + 1.0); }
static int isfull(int i) { return i & 1; }
static void build(const int *hu, const int *hv, int *u, int *v) {   /* half params for i <= c */
    for (int i = 0; i <= c; i++) { u[i] = hu[i]; v[i] = hv[i]; u[m - 1 - i] = hv[i]; v[m - 1 - i] = hu[i]; }
}
static int ok(const int *hu, const int *hv) {
    for (int i = 0; i <= c; i++) {
        if (hu[i] < 0 || hv[i] < 0 || hu[i] + hv[i] > D) return 0;
        if (isfull(i) && hu[i] + hv[i] != D) return 0;
        if (i == c && hu[i] != hv[i]) return 0;
    }
    return 1;
}
int main(int argc, char **argv) {
    D = atoi(argv[1]); m = atoi(argv[2]); srand(atoi(argv[3])); c = (m - 1) / 2;
    double TL = getenv("TL") ? atof(getenv("TL")) : 60, T0 = getenv("T0") ? atof(getenv("T0")) : 1.0;
    int hu[64], hv[64], u[64], v[64];
    if (getenv("START")) {                                   /* full instance file -> take first half */
        FILE *f = fopen(getenv("START"), "r"); int a, b, k = 0, fu[64], fv[64];
        while (k < m && fscanf(f, "%d %d", &a, &b) == 2) { fu[k] = a; fv[k] = b; k++; } fclose(f);
        for (int i = 0; i <= c; i++) { hu[i] = fu[i]; hv[i] = fv[i]; }
    } else {
        do { for (int i = 0; i <= c; i++) {
                 if (i == c && isfull(i)) { hu[i] = hv[i] = D / 2; continue; }
                 if (i == c) { hu[i] = hv[i] = rand() % (D / 2 + 1); continue; }
                 if (isfull(i)) { hu[i] = rand() % (D + 1); hv[i] = D - hu[i]; continue; }
                 int s = (rnd() < 0.5) ? D : rand() % (D + 1); hu[i] = rand() % (s + 1); hv[i] = s - hu[i]; }
        } while (!ok(hu, hv));
    }
    if (!ok(hu, hv)) { fprintf(stderr, "start violates structure\n"); return 1; }
    build(hu, hv, u, v);
    int a = alpha_dp(m, u, v, 1, 0); double E = escape(m, u, v, a, 0);
    int ba = a; double bE = E; int bu[64], bv[64]; memcpy(bu, u, sizeof u); memcpy(bv, v, sizeof v);
    printf("start alpha=%d/%d E=%.0f\n", a, D, E); fflush(stdout);
    clock_t t0 = clock(); long it = 0;
    while ((double)(clock() - t0) / CLOCKS_PER_SEC < TL) {
        it++;
        int nu[64], nv[64]; memcpy(nu, hu, sizeof nu); memcpy(nv, hv, sizeof nv);
        int i = rand() % (c + 1), d = 1 + (rnd() < 0.8 ? rand() % 3 : rand() % (D / 4 + 1)); if (rnd() < .5) d = -d;
        if (i == c) { nu[i] += d; nv[i] += d; }
        else if (isfull(i)) { nu[i] += d; nv[i] -= d; }
        else switch (rand() % 3) { case 0: nu[i] += d; nv[i] -= d; break; case 1: nu[i] += d; break; default: nv[i] += d; }
        if (rnd() < 0.15) { int j = rand() % (c + 1); if (j != c && !isfull(j)) { int t = nu[j]; nu[j] = nv[j]; nv[j] = t; } }
        if (!ok(nu, nv)) continue;
        int fu[64], fv[64]; build(nu, nv, fu, fv);
        int na = alpha_dp(m, fu, fv, 1, 0); double nE = escape(m, fu, fv, na, 0);
        double T = T0 * (1 - (double)(clock() - t0) / CLOCKS_PER_SEC / TL) + 1e-3;
        double g = (na - a) * 3.0 + (na == a ? log(E + 1) - log(nE + 1) : 0);
        if (g >= 0 || rnd() < exp(g / T)) {
            memcpy(hu, nu, sizeof nu); memcpy(hv, nv, sizeof nv); a = na; E = nE;
            if (a > ba || (a == ba && E < bE)) {
                if (a > ba) { printf("[%.1fs it %ld] alpha=%d/%d=%.6f E=%.0f\n", (double)(clock() - t0) / CLOCKS_PER_SEC, it, a, D, (double)a / D, E); fflush(stdout); }
                ba = a; bE = E; build(hu, hv, bu, bv);
            }
        }
        if (it % 100000 == 0 && a < ba && rnd() < 0.5) { for (int q = 0; q <= c; q++) { hu[q] = bu[q]; hv[q] = bv[q]; } a = ba; E = bE; }
    }
    printf("FINAL D=%d m=%d: alpha=%d/%d=%.6f (47/42=1.119048) E=%.0f its=%ld inst:", D, m, ba, D, (double)ba / D, bE, it);
    for (int q = 0; q < m; q++) printf(" (%d,%d)", bu[q], bv[q]); printf("\n");
}
