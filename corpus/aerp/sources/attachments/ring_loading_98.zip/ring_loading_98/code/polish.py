"""Continuous polishing of ssa results + exact certification.
usage: python3 polish.py ssa_output_files...      (reads FINAL lines, polishes those with alpha >= MIN/84)
Prints '*** NEW RECORD ***' and writes NEWREC_*.txt when an exactly certified alpha > 9/8 is found."""
import ctypes, os, re, sys, time
from fractions import Fraction as F
import numpy as np
from scipy.optimize import linprog

HERE = os.path.dirname(os.path.abspath(__file__))
L = ctypes.CDLL(os.path.join(HERE, 'librl.so')); LD = ctypes.CDLL(os.path.join(HERE, 'libdp.so'))
DP, IP, UP = ctypes.POINTER(ctypes.c_double), ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_uint32)
L.alpha_exact.restype = ctypes.c_double; L.alpha_exact.argtypes = [ctypes.c_int, DP, DP, UP]
L.tight.restype = ctypes.c_int; L.tight.argtypes = [ctypes.c_int, DP, DP, ctypes.c_double, UP, IP, IP, DP, ctypes.c_int]
L.set_def.argtypes = [ctypes.c_int]; L.set_def(1)                       # classic definition, k = 1..m
LD.alpha_brute.restype = ctypes.c_int; LD.alpha_brute.argtypes = [ctypes.c_int, IP, IP, ctypes.c_int]
RECORD = F(os.environ.get('REC', '9/8')); MIN = int(os.environ.get('MIN', '90'))

def alpha(u, v):
    u = np.ascontiguousarray(u, float); v = np.ascontiguousarray(v, float)
    return L.alpha_exact(len(u), u.ctypes.data_as(DP), v.ctypes.data_as(DP), None)

def tight(u, v, thr, maxout=20000):
    m = len(u); u = np.ascontiguousarray(u, float); v = np.ascontiguousarray(v, float)
    om = np.zeros(maxout, np.uint32); ok = np.zeros(maxout, np.int32); os_ = np.zeros(maxout, np.int32); og = np.zeros(maxout)
    c = L.tight(m, u.ctypes.data_as(DP), v.ctypes.data_as(DP), thr, om.ctypes.data_as(UP),
                ok.ctypes.data_as(IP), os_.ctypes.data_as(IP), og.ctypes.data_as(DP), maxout)
    return om[:c], ok[:c], os_[:c]

def slp(u, v, delta=0.05, tmax=40):
    m = len(u); a = alpha(u, v); t0 = time.time()
    while delta > 1e-10 and time.time() - t0 < tmax:
        om, ok, os_ = tight(u, v, a + max(0.15 * delta * m, 1e-9), 8000)
        bits = ((om[:, None] >> np.arange(m)[None, :]) & 1).astype(bool)
        c = np.where(np.arange(m)[None, :] < ok[:, None], 1.0, -1.0); s = os_[:, None].astype(float)
        A = np.hstack([s * np.where(~bits, c, 0.0), -s * np.where(bits, c, 0.0), np.ones((len(om), 1))])
        A2 = np.hstack([np.eye(m), np.eye(m), np.zeros((m, 1))])
        bnds = [(max(0, x - delta), min(1, x + delta)) for x in np.r_[u, v]] + [(None, None)]
        r = linprog(-np.eye(1, 2 * m + 1, 2 * m)[0], A_ub=np.vstack([A, A2]), b_ub=np.r_[np.zeros(len(om)), np.ones(m)],
                    bounds=bnds, method='highs')
        if r.status != 0: delta *= 0.5; continue
        nu, nv = r.x[:m], r.x[m:2 * m]; na = alpha(nu, nv)
        if na > a + 1e-13: u, v, a = nu, nv, na; delta = min(delta * 1.5, 0.3)
        else: delta *= 0.5
    return u, v, a

def certify(u, v):
    """find a common denominator, return exact Fraction alpha via integer brute force (or None)"""
    x = np.r_[u, v]
    for D in range(1, 20001):
        r = x * D
        if np.abs(r - np.round(r)).max() < 1e-7:
            iu = np.round(u * D).astype(np.int32); iv = np.round(v * D).astype(np.int32)
            if (iu < 0).any() or (iv < 0).any() or (iu + iv > D).any(): return None, None
            a = LD.alpha_brute(len(iu), iu.ctypes.data_as(IP), iv.ctypes.data_as(IP), 1)
            return F(a, D), (D, iu, iv)
    return None, None

for path in sys.argv[1:]:
    for line in open(path):
        mm = re.search(r'FINAL D=(\d+) m=(\d+): alpha=(\d+)/', line)
        if not mm: continue
        D0, m, a0 = int(mm.group(1)), int(mm.group(2)), int(mm.group(3))
        if a0 < MIN or m > 23: continue
        P = [tuple(map(int, p)) for p in re.findall(r'\((\d+),(\d+)\)', line.split('inst:')[1])]
        u = np.array([a for a, b in P], float) / D0; v = np.array([b for a, b in P], float) / D0
        nz = (u + v) > 0; u, v = u[nz], v[nz]
        t = time.time(); pu, pv, pa = slp(u, v)
        fa, cert = certify(pu, pv)
        tag = ''
        if fa is not None and fa > RECORD:
            tag = '   *** NEW RECORD ***'
            D, iu, iv = cert
            out = f"NEWREC_{os.path.basename(path).replace('.txt','')}_{fa.numerator}_{fa.denominator}.txt"
            np.savetxt(os.path.join(HERE, out), np.c_[iu, iv], fmt='%d', header=f'alpha = {fa} (classic def), grid D = {D}')
            tag += f'  saved {out}'
        print(f"{os.path.basename(path)}: m={m} grid {a0}/{D0} -> continuous {pa:.10f}"
              f" exact {fa if fa is not None else '?'}{tag}  [{time.time()-t:.0f}s]", flush=True)
