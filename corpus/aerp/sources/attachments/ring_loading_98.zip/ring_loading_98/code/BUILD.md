# Code

Exact checking (C):

    gcc -O2 check.c dp.c -o check
    ./check ../min98_m14_D16.txt 16        # classic: 18/16 by DP and brute force
    ./check ../min98_m14_D16_pad.txt 16    # 18/16 under both conventions

Search pipeline (Linux, uses numpy/scipy):

    gcc -O3 -march=native -shared -fPIC rl.c -o librl.so -lm
    gcc -O3 -march=native -shared -fPIC dp.c -o libdp.so
    gcc -O3 -march=native ssa.c dp.c ebit.c -o ssa -lm
    N=8 TL=1800 ./cycle.sh        # N parallel annealing runs of TL seconds, then polish.py on their results

- `ssa.c`: simulated annealing over palindromic integer instances (grid D), exact DP evaluation, plateau tie-break.
- `polish.py`: sequential LP refinement in continuous variables, rationalization and exact certification.
- `dp.c`: exact alpha for integer instances (dynamic program and brute force), both conventions.
- `rl.c`, `ebit.c`: helpers (floating-point alpha and near-tight patterns; escape-state count).
