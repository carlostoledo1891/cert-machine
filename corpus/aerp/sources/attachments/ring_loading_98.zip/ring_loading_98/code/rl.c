/* ring loading: exact alpha + near-tight patterns. alpha(u,v) = min_z max_{k=1..m-1} |sum z[:k] - sum z[k:]| */
#include <math.h>
#include <stdint.h>
int DEF = 0;   /* 0: DeepMind (k=1..m-1)  1: classic (k=1..m, i.e. also |T|) */
/* g(mask) with early exit at cap; returns value and argmax k (number of leading elems) and sign */
static inline double gz(int m, const double *u, const double *v, uint32_t mask, double cap, int *kk, int *ss) {
    double z[40], T = 0;
    for (int i = 0; i < m; i++) { z[i] = (mask >> i & 1) ? v[i] : -u[i]; T += z[i]; }
    double S = 0, w = -1; int bk = 1, bs = 1;
    if (DEF == 1) { w = fabs(T); bk = m; bs = T >= 0 ? 1 : -1; if (w > cap) { if (kk) { *kk = bk; *ss = bs; } return w; } }
    for (int k = 1; k < m; k++) {
        S += z[k - 1]; double d = 2 * S - T, a = fabs(d);
        if (a > w) { w = a; bk = k; bs = d >= 0 ? 1 : -1; if (w > cap) break; }
    }
    if (kk) { *kk = bk; *ss = bs; }
    return w;
}
double alpha_exact(int m, const double *u, const double *v, uint32_t *argmask) {
    double best = 1e18; uint32_t N = 1u << m, bm = 0;
    for (uint32_t mask = 0; mask < N; mask++) {
        double w = gz(m, u, v, mask, best, 0, 0);
        if (w < best) { best = w; bm = mask; }
    }
    if (argmask) *argmask = bm;
    return best;
}
/* list patterns with g <= thr; returns count (<= maxout) */
int tight(int m, const double *u, const double *v, double thr, uint32_t *om, int *ok, int *os, double *og, int maxout) {
    uint32_t N = 1u << m; int c = 0;
    for (uint32_t mask = 0; mask < N && c < maxout; mask++) {
        int k, s; double w = gz(m, u, v, mask, thr, &k, &s);
        if (w <= thr) { om[c] = mask; ok[c] = k; os[c] = s; og[c] = w; c++; }
    }
    return c;
}

void set_def(int d) { DEF = d; }
