"""Independent check: pure Python, exact Fractions, no C code. Both definitions + DeepMind's own compute_alpha_exact."""
import sys, itertools
from fractions import Fraction as F
import numpy as np
d = np.loadtxt(sys.argv[1]).astype(int); D = int(sys.argv[2])
u = [F(int(a), D) for a in d[:, 0]]; v = [F(int(b), D) for b in d[:, 1]]; m = len(u)
assert all(x >= 0 for x in u + v) and all(a + b <= 1 for a, b in zip(u, v))
best_c = best_d = None
for z in itertools.product(*[(v[i], -u[i]) for i in range(m)]):
    T = sum(z); S = F(0); vals = []
    for k in range(0, m + 1):
        vals.append(abs(2 * S - T))
        if k < m: S += z[k]
    c = max(vals); dm = max(vals[1:m])            # classic: k=0..m ; DeepMind: k=1..m-1
    if best_c is None or c < best_c: best_c = c
    if best_d is None or dm < best_d: best_d = dm
print(f"m={m}  classic alpha = {best_c} = {float(best_c):.10f}   DeepMind alpha = {best_d} = {float(best_d):.10f}")
print(f"47/42 = {float(F(47,42)):.10f};  classic > 47/42: {best_c > F(47,42)};  DeepMind > 47/42: {best_d > F(47,42)}")
