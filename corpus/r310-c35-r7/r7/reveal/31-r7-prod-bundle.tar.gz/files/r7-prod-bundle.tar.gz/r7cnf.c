/* r7cnf.c — the projected R(7) CNF for one configuration (Claude, 2026-11-21).
 *
 * Chen's cases/r7_glue.py CNF for core X with the four side rows fixed, simplified: variables x[c][y] (c = 0..6 the C
 * vertices, y = 0..26), var id 1 + 27c + y.
 *   (T) each C row independent in X: (-x[c,y] | -x[c,y']) for every edge yy' of X.
 *   (D) each C row has exactly 7 vertices; each y is in exactly r'(y) = 9 - deg_X(y) - #side rows on y C rows
 *       (sequential counters, Sinz 2005).
 *   (I) for every independent I of X with m = |I| >= 1, let mQ = #rows of side Q missing I and
 *       k = K + 1 - m - max(mA, mB). If k <= 7: for every k-subset C' of C, OR_{c in C', y in I} x[c,y]
 *       ("at most k - 1 C rows miss I"). These are Chen's clauses for T' = C' + A' (A' = the A rows missing I) or C' + B'
 *       after the fixed rows are substituted; clauses with a larger A' or C' are subsumed and omitted; Chen's
 *       {u}+B, {w}+A clauses are satisfied by the configuration's root condition (checked here; exit 4 if not).
 *   (S) optional (SB=1): rows in lexicographic order, row c <=lex row c+1 (y = 0 most significant). The 7 C vertices
 *       are interchangeable in every clause above, so this keeps one representative of each solution.
 * usage: r7cnf cores.g6 configs.bin IDX K SB [MAXI] > out.cnf     (MAXI: only |I| <= MAXI in (I); default 7 = all;
 *        added 2026-11-22 after the pilot; without it the output is byte-identical to the pilot generator's)
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
typedef uint32_t u32;
static u32 adjX[27]; static int degX[27];
static u32 IS[20000]; static int nIS;
static u32 L6[4000]; static int n6;
static void rec(int start, u32 set, u32 cand) {
  IS[nIS++] = set;
  for (int v = start; v < 27; v++) if ((cand >> v) & 1) rec(v + 1, set | (1u << v), cand & ~adjX[v] & ~((2u << v) - 1));
}
/* clause buffer */
static int *cl; static long ncl, cap, nlit; static int nv;
static void lit(int l) { if (nlit == cap) { cap = cap ? 2 * cap : 1 << 20; cl = realloc(cl, cap * sizeof(int)); } cl[nlit++] = l; }
static void end(void) { lit(0); ncl++; }
/* sequential counter: at most k of lits[0..n-1] */
static void atmost(const int *x, int n, int k) {
  if (k >= n) return;
  if (k == 0) { for (int i = 0; i < n; i++) { lit(-x[i]); end(); } return; }
  int base = nv; nv += n * k;   /* s[i][j] = base + i*k + j + 1, i = 0..n-1, j = 0..k-1 */
  #define SV(i, j) (base + (i) * k + (j) + 1)
  lit(-x[0]); lit(SV(0, 0)); end();
  for (int j = 1; j < k; j++) { lit(-SV(0, j)); end(); }
  for (int i = 1; i < n; i++) {
    lit(-x[i]); lit(SV(i, 0)); end();
    lit(-SV(i - 1, 0)); lit(SV(i, 0)); end();
    for (int j = 1; j < k; j++) {
      lit(-x[i]); lit(-SV(i - 1, j - 1)); lit(SV(i, j)); end();
      lit(-SV(i - 1, j)); lit(SV(i, j)); end();
    }
    lit(-x[i]); lit(-SV(i - 1, k - 1)); end();
  }
  #undef SV
}
static void exactly(const int *x, int n, int k) {
  atmost(x, n, k);
  int y[64]; for (int i = 0; i < n; i++) y[i] = -x[i];
  atmost(y, n, n - k);          /* at least k true  <=>  at most n - k false */
}
#define X(c, y) (1 + 27 * (c) + (y))
int main(int argc, char **argv) {
  if (argc < 6) { fprintf(stderr, "usage\n"); return 2; }
  long idx = atol(argv[3]); int K = atoi(argv[4]), SB = atoi(argv[5]); int MAXI = argc > 6 ? atoi(argv[6]) : 7;
  FILE *g = fopen(argv[2], "rb"); uint16_t q[5]; fseek(g, idx * 10, SEEK_SET); if (fread(q, 2, 5, g) != 5) return 3; fclose(g);
  FILE *f = fopen(argv[1], "r"); char line[512]; int c = 0;
  while (fgets(line, sizeof line, f)) { if (strlen(line) < 5) continue; if (c++ == q[0]) break; }
  int bi = 1, bit = 5;
  for (int j = 1; j < 27; j++) for (int i = 0; i < j; i++) { int b = ((line[bi] - 63) >> bit) & 1; if (--bit < 0) { bit = 5; bi++; } if (b) { adjX[i] |= 1u << j; adjX[j] |= 1u << i; } }
  for (int i = 0; i < 27; i++) degX[i] = __builtin_popcount(adjX[i]);
  rec(0, 0, (1u << 27) - 1);
  for (int k = 0; k < nIS; k++) if (__builtin_popcount(IS[k]) == 6) L6[n6++] = IS[k];
  u32 side[4] = { L6[q[1]], L6[q[2]], L6[q[3]], L6[q[4]] };
  int r[27]; for (int y = 0; y < 27; y++) { r[y] = 9 - degX[y]; for (int s = 0; s < 4; s++) r[y] -= (side[s] >> y) & 1; if (r[y] < 0) return 4; }
  if ((side[0] | side[1]) & (side[2] | side[3])) return 4;
  nv = 7 * 27;
  /* (T) */
  for (int cc = 0; cc < 7; cc++) for (int y = 0; y < 27; y++) for (int z = y + 1; z < 27; z++) if ((adjX[y] >> z) & 1) { lit(-X(cc, y)); lit(-X(cc, z)); end(); }
  /* (D) */
  for (int cc = 0; cc < 7; cc++) { int x[27]; for (int y = 0; y < 27; y++) x[y] = X(cc, y); exactly(x, 27, 7); }
  for (int y = 0; y < 27; y++) { int x[7]; for (int cc = 0; cc < 7; cc++) x[cc] = X(cc, y); exactly(x, 7, r[y]); }
  /* (I) */
  long nI = 0;
  for (int t = 0; t < nIS; t++) {
    u32 I = IS[t]; int m = __builtin_popcount(I); if (!m) continue;
    int mA = !(side[0] & I) + !(side[1] & I), mB = !(side[2] & I) + !(side[3] & I);
    if (m + 1 + mA > K || m + 1 + mB > K) return 4;   /* {w}+A+I or {u}+B+I independent of size K+1 */
    int k = K + 1 - m - (mA > mB ? mA : mB);
    if (k <= 0) return 4;
    if (k > 7 || m > MAXI) continue;   /* MAXI < 7 keeps a SUBSET of the (I) clauses: UNSAT of the subset implies UNSAT of the whole */
    for (int sub = 0; sub < 128; sub++) if (__builtin_popcount(sub) == k) {
      for (int cc = 0; cc < 7; cc++) if ((sub >> cc) & 1) for (int y = 0; y < 27; y++) if ((I >> y) & 1) lit(X(cc, y));
      end(); nI++;
    }
  }
  /* (S) */
  if (SB) for (int cc = 0; cc + 1 < 7; cc++) {
    int e0 = ++nv; lit(e0); end();
    int e = e0;
    for (int y = 0; y < 27; y++) {
      int a = X(cc, y), b = X(cc + 1, y);
      lit(-e); lit(-a); lit(b); end();                 /* equal so far -> a_y <= b_y */
      if (y == 26) break;
      int e2 = ++nv;
      lit(-e); lit(-a); lit(-b); lit(e2); end();       /* equal so far and a_y = b_y -> equal through y */
      lit(-e); lit(a); lit(b); lit(e2); end();
      e = e2;
    }
  }
  if (MAXI < 7) printf("c r7cnf core=%d cfg=%ld K=%d SB=%d MAXI=%d independence-clauses=%ld\n", q[0], idx, K, SB, MAXI, nI);
  else printf("c r7cnf core=%d cfg=%ld K=%d SB=%d independence-clauses=%ld\n", q[0], idx, K, SB, nI);
  printf("p cnf %d %ld\n", nv, ncl);
  for (long i = 0; i < nlit; i++) { if (cl[i]) printf("%d ", cl[i]); else printf("0\n"); }
  return 0;
}
