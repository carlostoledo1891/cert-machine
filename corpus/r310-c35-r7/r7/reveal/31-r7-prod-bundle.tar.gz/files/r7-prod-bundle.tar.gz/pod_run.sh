#!/bin/bash
# pod_run.sh — build the pinned tools on a Linux x86-64 pod, run the controls, then the production run (PROD-PREREG.md).
# Run inside the unpacked bundle. Re-running resumes: finished records are skipped.
set -euo pipefail
cd "$(dirname "$0")"
sha256sum -c PROD-PINS.sha256
apt-get update -qq && apt-get install -y -qq build-essential git python3 > /dev/null
mkdir -p build out
if [ ! -x build/cadical/build/cadical ]; then
  git clone -q https://github.com/arminbiere/cadical.git build/cadical
  ( cd build/cadical && git checkout -q c60730422e758ef1cebe7aeddf2dda31c996bf04 && ./configure > /dev/null && make -j"$(nproc)" > /dev/null )
fi
cc -O3 -o r7cnf r7cnf.c
cc -O2 -o build/lrat-check tools-src/drat-trim/lrat-check.c
make -s -C tools-src/cake
export R7_DIR="$PWD" CADICAL="$PWD/build/cadical/build/cadical" LRATCHECK="$PWD/build/lrat-check" CAKELPR="$PWD/tools-src/cake/cake_lpr" R7_TMP=/dev/shm
{ uname -a; nproc; "$CADICAL" --version; sha256sum "$CADICAL" "$LRATCHECK" "$CAKELPR" r7cnf; date -u +%FT%TZ; } | tee out/RUN-MACHINE.txt
W=$(nproc)
python3 prod.py run --K 10 --list control_k10_sat.txt      --workers "$W" --ledger out/control_k10_sat.tsv
python3 prod.py run --K 10 --list control_k10_cores123.txt --workers "$W" --ledger out/control_k10_cores123.tsv
python3 prod.py run --K 9  --list control_trunc.txt --truncate --workers "$W" --ledger out/control_trunc.tsv
python3 prod.py run --K 9  --list pilot_m1.txt             --workers "$W" --ledger out/identity_1200.tsv
python3 check_controls.py out | tee out/CONTROLS.txt
python3 prod.py run --K 9 --range 0 977008 --workers "$W" --ledger out/prod.tsv --budget 1440000 | tee -a out/prod.log
python3 prod.py tally --ledger out/prod.tsv --expect 977008 | tee out/TALLY.txt || true
sha256sum out/prod.tsv out/*.tsv out/CONTROLS.txt out/TALLY.txt out/RUN-MACHINE.txt > out/OUT.sha256
date -u +%FT%TZ | tee -a out/RUN-MACHINE.txt
