#!/usr/bin/env python3
"""prod.py — the R(7) production pipeline (PROD-PREREG.md). Python 3 standard library only; macOS and Linux.

One record per configuration. For configuration idx at independence bound K:
  level 3: r7cnf (lex row order, independence clauses for |I| <= 3) -> CaDiCaL (LRAT text proof)
           UNSAT   -> lrat-check and cake_lpr on that CNF and proof; both accept -> CERTIFIED-UNSAT, else OPEN(checker)
           SAT     -> the kept clauses are too few: go to level 4, then level 7 (the full projected CNF)
           UNKNOWN -> (CaDiCaL cap) go to the next level; after level 7: OPEN(timeout)
  level 7 SAT: the model is decoded into the 40-vertex graph and checked directly here (9-regular, triangle-free,
           independence number by branch and bound). Outcome SAT-GRAPH-VERIFIED or SAT-GRAPH-REJECTED. At K = 9 either
           one writes STOP and ends the run; the graph is in the record.
The CNF and the proof are deleted after their sha256 and both checkers' verdict lines are recorded.

usage:
  prod.py run   --K 9 --list FILE|--range A B --workers N --ledger OUT.tsv [--budget CPU_SECONDS] [--truncate]
  prod.py tally --ledger OUT.tsv [OUT2.tsv ...] --expect N
Environment: R7_DIR (folder with r7cnf, cores_e85.g6, configs.bin), CADICAL, LRATCHECK, CAKELPR, R7_TMP.
--truncate (control): the proof is cut to its first half before the checkers run; both must refuse it.
"""
import argparse, hashlib, os, resource, struct, subprocess, sys, tempfile, time
from concurrent.futures import ProcessPoolExecutor, wait, FIRST_COMPLETED

D = os.environ.get('R7_DIR', os.path.dirname(os.path.abspath(__file__)))
CADICAL = os.environ.get('CADICAL', 'cadical')
LRATCHECK = os.environ.get('LRATCHECK', 'lrat-check')
CAKELPR = os.environ.get('CAKELPR', 'cake_lpr')
TMP = os.environ.get('R7_TMP', tempfile.gettempdir())
CAP_SOLVE, CAP_CHECK, PROOF_LIMIT = 300, 300, 4 << 30
LEVELS = (3, 4, 7)
FIELDS = ['idx', 'K', 'outcome', 'level', 'trail', 'cnf_sha256', 'proof_sha256', 'lrat_check_line', 'cake_lpr_line', 'clauses',
          'cnf_bytes', 'proof_bytes', 'cpu_gen', 'cpu_solve', 'cpu_lrat', 'cpu_cake', 'graph']


def child_cpu():
    r = resource.getrusage(resource.RUSAGE_CHILDREN); return r.ru_utime + r.ru_stime


def run(cmd, timeout, stdout_path=None, fsize=None):
    """Run cmd; return (returncode or None on timeout, stdout text, child CPU seconds)."""
    def pre():
        if fsize: resource.setrlimit(resource.RLIMIT_FSIZE, (fsize, fsize))
    c0 = child_cpu()
    try:
        if stdout_path:
            with open(stdout_path, 'wb') as f:
                p = subprocess.run(cmd, stdout=f, stderr=subprocess.DEVNULL, timeout=timeout, preexec_fn=pre); out = ''
        else:
            p = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=timeout, preexec_fn=pre)
            out = p.stdout.decode('ascii', 'replace')
        rc = p.returncode
    except subprocess.TimeoutExpired:
        rc, out = None, ''
    return rc, out, child_cpu() - c0


def sha256(path):
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        for b in iter(lambda: f.read(1 << 20), b''): h.update(b)
    return h.hexdigest()


# ---------- the direct check of a decoded graph (independent of r7cnf and of the solver) ----------
_cores = None
def cores():
    global _cores
    if _cores is None:
        _cores = []
        for line in open(os.path.join(D, 'cores_e85.g6')):
            line = line.strip()
            if not line: continue
            d = [ord(c) - 63 for c in line]; bits = []
            for x in d[1:]:
                for k in range(5, -1, -1): bits.append((x >> k) & 1)
            adj = [0] * 27; t = 0
            for j in range(1, 27):
                for i in range(j):
                    if bits[t]: adj[i] |= 1 << j; adj[j] |= 1 << i
                    t += 1
            L6 = []
            def rec(start, size, s, cand):
                if size == 6: L6.append(s)
                if size == 7: return
                for v in range(start, 27):
                    if (cand >> v) & 1: rec(v + 1, size + 1, s | (1 << v), cand & ~adj[v] & ~((2 << v) - 1))
            rec(0, 0, 0, (1 << 27) - 1)
            _cores.append((adj, L6))
    return _cores


def alpha(adj, n):
    best = 0
    def go(cand, cur):
        nonlocal best
        if not cand:
            best = max(best, cur); return
        if cur + bin(cand).count('1') <= best: return
        bv, bd, t = -1, -1, cand
        while t:
            v = (t & -t).bit_length() - 1; t &= t - 1
            d = bin(adj[v] & cand).count('1')
            if d > bd: bd, bv = d, v
        if bd == 0:
            best = max(best, cur + bin(cand).count('1')); return
        go(cand & ~adj[bv] & ~(1 << bv), cur + 1)
        go(cand & ~(1 << bv), cur)
    go((1 << n) - 1, 0)
    return best


def decode_and_check(idx, K, solver_out):
    """Model -> rows -> the 40-vertex graph -> (9-regular, triangle-free, alpha <= K). Returns (ok, description)."""
    true = set()
    for line in solver_out.splitlines():
        if line.startswith('v '):
            true.update(int(t) for t in line.split()[1:] if int(t) > 0)
    with open(os.path.join(D, 'configs.bin'), 'rb') as f:
        f.seek(10 * idx); c, a1, a2, b1, b2 = struct.unpack('<5H', f.read(10))
    adjX, L6 = cores()[c]
    rows = [sum(1 << y for y in range(27) if (1 + 27 * k + y) in true) for k in range(7)] + [L6[a1], L6[a2], L6[b1], L6[b2]]
    adj = [0] * 40
    def E(a, b): adj[a] |= 1 << b; adj[b] |= 1 << a
    for i in range(27):
        for j in range(i + 1, 27):
            if (adjX[i] >> j) & 1: E(i, j)
    for k in range(7): E(27, 29 + k); E(28, 29 + k)
    E(27, 36); E(27, 37); E(28, 38); E(28, 39)
    for a in (36, 37):
        for b in (38, 39): E(a, b)
    for s in range(11):
        for y in range(27):
            if (rows[s] >> y) & 1: E(29 + s, y)
    regular = all(bin(a).count('1') == 9 for a in adj)
    tri = any((adj[i] >> j) & 1 and adj[i] & adj[j] for i in range(40) for j in range(i + 1, 40))
    al = alpha(adj, 40)
    ok = regular and not tri and al <= K
    desc = 'core=%d;rows=%s;regular9=%d;triangle_free=%d;alpha=%d' % (c, ','.join('%07x' % r for r in rows), regular, not tri, al)
    return ok, desc


# ---------- one configuration ----------
def one(job):
    idx, K, truncate = job
    w = os.path.join(TMP, 'r7_%d_%d' % (os.getpid(), idx))
    cnf, prf = w + '.cnf', w + '.lrat'
    rec = dict.fromkeys(FIELDS, '-'); rec.update(idx=idx, K=K)
    trail = []; cg = cs = cl = ck = 0.0
    try:
        for lv in LEVELS:
            rc, _, t = run([os.path.join(D, 'r7cnf'), os.path.join(D, 'cores_e85.g6'), os.path.join(D, 'configs.bin'), str(idx), str(K), '1', str(lv)], 120, stdout_path=cnf)
            cg += t
            if rc != 0:
                trail.append('%d:GEN-FAIL(%s)' % (lv, rc)); rec.update(outcome='OPEN(gen-fail)', level=lv); break
            if os.path.exists(prf): os.remove(prf)
            rc, out, t = run([CADICAL, '-q', '-t', str(CAP_SOLVE), '--lrat', '--binary=false', cnf, prf], CAP_SOLVE + 60, fsize=PROOF_LIMIT)
            cs += t
            st = next((l[2:].strip() for l in out.splitlines() if l.startswith('s ')), 'UNKNOWN')
            if st == 'SATISFIABLE':
                trail.append('%d:SAT' % lv)
                if lv < 7: continue
                ok, desc = decode_and_check(idx, K, out)
                rec.update(outcome='SAT-GRAPH-VERIFIED' if ok else 'SAT-GRAPH-REJECTED', level=lv, graph=desc, cnf_sha256=sha256(cnf), cnf_bytes=os.path.getsize(cnf))
                break
            if st != 'UNSATISFIABLE':
                trail.append('%d:UNKNOWN' % lv)
                if lv < 7: continue
                rec.update(outcome='OPEN(timeout)', level=lv); break
            trail.append('%d:UNSAT' % lv)
            with open(cnf, 'rb') as f: f.readline(); head = f.readline().split()
            rec.update(level=lv, clauses=int(head[3]), cnf_bytes=os.path.getsize(cnf), cnf_sha256=sha256(cnf), proof_bytes=os.path.getsize(prf), proof_sha256=sha256(prf))
            if truncate:
                n = os.path.getsize(prf) // 2
                with open(prf, 'rb') as f: data = f.read(n)
                data = data[:data.rfind(b'\n') + 1]
                with open(prf, 'wb') as f: f.write(data)
            rc, out, t = run([LRATCHECK, cnf, prf], CAP_CHECK); cl += t
            l1 = next((l.strip() for l in out.splitlines() if l.startswith('c VERIFIED')), None)
            rc, out, t = run([CAKELPR, cnf, prf], CAP_CHECK); ck += t
            l2 = next((l.strip() for l in out.splitlines() if l.startswith('s VERIFIED UNSAT')), None)
            rec.update(lrat_check_line=l1 or 'REFUSED', cake_lpr_line=l2 or 'REFUSED')
            rec['outcome'] = 'CERTIFIED-UNSAT' if (l1 and l2) else 'OPEN(checker)'
            break
    finally:
        for p in (cnf, prf):
            if os.path.exists(p): os.remove(p)
    rec.update(trail=','.join(trail), cpu_gen='%.2f' % cg, cpu_solve='%.2f' % cs, cpu_lrat='%.2f' % cl, cpu_cake='%.2f' % ck)
    return rec


def read_ledger(paths):
    recs = {}
    for p in paths:
        if not os.path.exists(p): continue
        for line in open(p):
            f = line.rstrip('\n').split('\t')
            if f[0] == 'idx' or len(f) < len(FIELDS): continue
            recs.setdefault(int(f[0]), []).append(dict(zip(FIELDS, f)))
    return recs


def main():
    ap = argparse.ArgumentParser(); ap.add_argument('mode', choices=['run', 'tally'])
    ap.add_argument('--K', type=int, default=9); ap.add_argument('--list'); ap.add_argument('--range', nargs=2, type=int)
    ap.add_argument('--workers', type=int, default=4); ap.add_argument('--ledger', nargs='+', required=True)
    ap.add_argument('--budget', type=float, default=0); ap.add_argument('--truncate', action='store_true'); ap.add_argument('--expect', type=int)
    a = ap.parse_args()
    if a.mode == 'tally':
        recs = read_ledger(a.ledger); out = {}; dup = [i for i, r in recs.items() if len(r) > 1]
        for r in recs.values():
            for x in r: out[x['outcome']] = out.get(x['outcome'], 0) + 1
        lv = {}
        for r in recs.values():
            if r[0]['outcome'] == 'CERTIFIED-UNSAT': lv[r[0]['level']] = lv.get(r[0]['level'], 0) + 1
        cpu = sum(float(x[k]) for r in recs.values() for x in r for k in ('cpu_gen', 'cpu_solve', 'cpu_lrat', 'cpu_cake'))
        missing = (a.expect - len(recs)) if a.expect else None
        print('records', len(recs), 'outcomes', out, 'certified by level', lv, 'duplicates', len(dup), 'missing (OPEN, not run)', missing, 'cpu_s %.0f' % cpu)
        complete = a.expect and len(recs) == a.expect and not dup and out == {'CERTIFIED-UNSAT': a.expect} and set(recs) == set(range(a.expect))
        print('ALL CERTIFIED-UNSAT' if complete else 'NOT COMPLETE')
        return 0 if complete else 1
    ledger = a.ledger[0]; stop = ledger + '.STOP'
    if os.path.exists(stop): print('STOP file present:', stop); return 3
    todo = [int(x) for x in open(a.list).read().split()] if a.list else list(range(a.range[0], a.range[1]))
    done = read_ledger([ledger]); todo = [i for i in todo if i not in done]
    new = not os.path.exists(ledger)
    spent = sum(float(x[k]) for r in done.values() for x in r for k in ('cpu_gen', 'cpu_solve', 'cpu_lrat', 'cpu_cake'))
    margin = a.workers * (3 * (CAP_SOLVE + 2 * CAP_CHECK))        # every in-flight item at all its caps
    t0 = time.time(); n = 0; it = iter(todo); live = set(); halted = False
    with open(ledger, 'a') as out, ProcessPoolExecutor(a.workers) as pool:
        if new: out.write('\t'.join(FIELDS) + '\n')
        while True:
            # at most 2 x workers submitted; once the budget line is reached nothing new is submitted and the queued
            # ones are cancelled, so only the <= workers running items can still spend (the margin covers them at caps)
            over = bool(a.budget) and spent >= a.budget - margin
            while not over and not halted and len(live) < 2 * a.workers:
                i = next(it, None)
                if i is None: break
                live.add(pool.submit(one, (i, a.K, a.truncate)))
            if over:
                for f in list(live):
                    if f.cancel(): live.discard(f)
            if not live: break
            fin, live = wait(live, return_when=FIRST_COMPLETED)
            for f in fin:
                rec = f.result()
                out.write('\t'.join(str(rec[k]) for k in FIELDS) + '\n'); out.flush(); n += 1
                spent += sum(float(rec[k]) for k in ('cpu_gen', 'cpu_solve', 'cpu_lrat', 'cpu_cake'))
                if rec['outcome'].startswith('SAT-GRAPH') and a.K == 9 and not halted:
                    halted = True
                    open(stop, 'w').write('\t'.join(str(rec[k]) for k in FIELDS) + '\n')
                    print('STOP: SAT on the full CNF at K = 9, configuration', rec['idx'], rec['graph'], flush=True)
                    for g in list(live):
                        if g.cancel(): live.discard(g)
                if n % 5000 == 0: print('%d done, %.0f CPU-s, %.0f s wall' % (n, spent, time.time() - t0), flush=True)
    if halted: return 3
    print('run ended: %d new records, %d left unstarted, %.0f CPU-s in this ledger, %.0f s wall' % (n, len(todo) - n, spent, time.time() - t0))
    return 0


if __name__ == '__main__':
    sys.exit(main())
