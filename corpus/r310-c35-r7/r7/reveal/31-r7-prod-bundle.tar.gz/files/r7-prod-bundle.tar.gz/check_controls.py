#!/usr/bin/env python3
"""check_controls.py — the pass/fail rules for the production controls (PROD-PREREG.md). Exit 0 only if all pass.
usage: check_controls.py DIR   (DIR holds control_k10_sat.tsv, control_k10_cores123.tsv, control_trunc.tsv, identity_1200.tsv;
the reference m3.ledger and configs.bin are read from this script's folder)"""
import os, struct, sys
H = os.path.dirname(os.path.abspath(__file__)); Dr = sys.argv[1]
def load(name):
    rows = [l.rstrip('\n').split('\t') for l in open(os.path.join(Dr, name))]
    return [dict(zip(rows[0], r)) for r in rows[1:]]
cfg = open(os.path.join(H, 'configs.bin'), 'rb').read()
core = lambda i: struct.unpack_from('<H', cfg, 10 * int(i))[0]
ok = True
def rule(name, passed, detail):
    global ok; ok &= bool(passed); print(('PASS  ' if passed else 'FAIL  ') + name + ': ' + detail)
a = load('control_k10_sat.tsv'); want = set(open(os.path.join(H, 'control_k10_sat.txt')).read().split())
rule('C-SAT', {r['idx'] for r in a} == want and all(r['outcome'] == 'SAT-GRAPH-VERIFIED' for r in a),
     '%d of %d end SAT with a verified graph' % (sum(r['outcome'] == 'SAT-GRAPH-VERIFIED' for r in a), len(want)))
b = load('control_k10_cores123.tsv'); per = {1: 0, 2: 0, 3: 0}
for r in b:
    if r['outcome'] == 'SAT-GRAPH-VERIFIED': per[core(r['idx'])] += 1
rej = sum(r['outcome'] == 'SAT-GRAPH-REJECTED' for r in b)
out = {}
for r in b: out[r['outcome']] = out.get(r['outcome'], 0) + 1
rule('C-CORES', rej == 0 and all(per[c] >= 1 for c in per), 'verified K = 10 graphs per core %s; outcomes %s' % (per, out))
t = load('control_trunc.tsv')
rule('C-TRUNC', len(t) == 24 and all(r['outcome'] == 'OPEN(checker)' and r['lrat_check_line'] == 'REFUSED' and r['cake_lpr_line'] == 'REFUSED' for r in t),
     '%d of %d truncated proofs refused by both checkers' % (sum(r['lrat_check_line'] == 'REFUSED' and r['cake_lpr_line'] == 'REFUSED' for r in t), len(t)))
ref = {}
for l in open(os.path.join(H, 'm3.ledger')):
    f = l.rstrip('\n').split('\t')
    if f[0] != 'idx' and len(f) >= 14 and f[2] == 'UNSATISFIABLE': ref[f[0]] = (f[1], f[12], f[13])
d = load('identity_1200.tsv'); same_lv = same_cnf = same_prf = cert = 0
for r in d:
    x = ref.get(r['idx'])
    cert += r['outcome'] == 'CERTIFIED-UNSAT'
    if x: same_lv += r['level'] == x[0]; same_cnf += r['cnf_sha256'][:16] == x[1]; same_prf += r['proof_sha256'][:16] == x[2]
rule('C-IDENTITY', len(d) == 1200 and cert == 1200 and same_cnf == 1200 and same_lv == 1200,
     '%d records, %d certified, same level %d, same CNF sha256 prefix %d (proof sha256 prefix equal on %d: a measurement, not a rule)' % (len(d), cert, same_lv, same_cnf, same_prf))
print('CONTROLS PASS' if ok else 'CONTROLS FAIL'); sys.exit(0 if ok else 1)
