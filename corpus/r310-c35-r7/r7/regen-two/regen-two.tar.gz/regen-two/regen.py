#!/usr/bin/env python3
"""Replay the deciding level of the two full-CNF records in the R(7) ledger."""

import argparse
import hashlib
import os
from pathlib import Path
import shutil
import struct
import subprocess
import sys
import tarfile


BUNDLE = "31-r7-prod-bundle.tar.gz/files/r7-prod-bundle.tar.gz"
CONFIGS = "08-configs.bin/files/configs.bin"
BUNDLE_SHA = "5666807cab6db618d7a0316a7333de433dc5236a466c170e62c8ffcf4388a2d3"
CONFIGS_SHA = "76c2666b7f2c4de5d54951cf2ba5e17337c541fa89b5e39ce5d9de45142ced9e"
CADICAL_URL = "https://github.com/arminbiere/cadical.git"
COMMIT = "c60730422e758ef1cebe7aeddf2dda31c996bf04"
ARCHIVE_SHA = "2dccd6ecc1878348dd70194d51df6b69006bf86439b5b3c395a5c5dd8863201e"
# idx -> (core, deciding CNF SHA-256, production LRAT SHA-256)
CASES = {
    332942: (1, "35f616ed7bff001b86f17ee1772e6551ad227dea8bf63fe4d75ee6d7ec0543f1",
             "d2556d836453432151a7876404cad7f56f8f6b77a9bf6cb6b470f9317392a985"),
    745446: (2, "265986376c70f767de2aac5bcd0115ff35c05bf382375088ba06f617ae317176",
             "96c6450f8b8efa1d862da3595b305a24e02f364f5dfcd740db4c289bd9a85148"),
}


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def compare(path, expected):
    actual = digest(path)
    equal = actual == expected
    print(f"{path.name}  sha256={actual}  {'MATCH' if equal else 'MISMATCH'}", flush=True)
    if not equal:
        print(f"  expected {expected}", flush=True)
    return equal


def prepare_generator(bundle, build, full):
    members = ["r7cnf.c", "cores_e85.g6"]
    if full:
        members.extend(["tools-src/drat-trim/lrat-check.c", "tools-src/cake/Makefile",
                        "tools-src/cake/basis_ffi.c", "tools-src/cake/cake_lpr.S",
                        "tools-src/cake/cake_lpr_arm8.S"])
    with tarfile.open(bundle, "r:gz") as tar:
        for name in members:
            dest = build / name
            dest.parent.mkdir(parents=True, exist_ok=True)
            with tar.extractfile(name) as src, dest.open("xb") as dst:
                shutil.copyfileobj(src, dst)
    subprocess.run(["cc", "-O3", "-o", "r7cnf", "r7cnf.c"], cwd=build, check=True)


def export_git_tree(build, src, repo):
    # Read only the committed tree, even when the reviewer's checkout has edits.
    if repo is None:
        repo = build / "upstream.git"
        subprocess.run(["git", "-c", "fetch.fsckObjects=true", "clone", "--bare",
                        CADICAL_URL, str(repo)], check=True)
    git = ["git", "--no-replace-objects", "-C", str(repo)]
    tree = subprocess.check_output(git + ["rev-parse", "--verify", COMMIT + "^{commit}"],
                                   text=True).strip()
    if tree != COMMIT:
        raise RuntimeError(f"unexpected CaDiCaL commit: {tree}")
    print(f"CaDiCaL source commit {tree}", flush=True)
    archive = build / "upstream.tar"
    subprocess.run(git + ["archive", "--format=tar", "--output=" + str(archive), COMMIT],
                   check=True)
    subprocess.run(["tar", "-xf", str(archive)], cwd=src, check=True)


def extract_pinned_archive(archive, src):
    if not compare(archive, ARCHIVE_SHA):
        raise RuntimeError("CaDiCaL source archive differs from the pinned download")
    prefix = "cadical-" + COMMIT
    with tarfile.open(archive, "r:gz") as tar:
        if tar.pax_headers.get("comment") != COMMIT:
            raise RuntimeError("unexpected commit in CaDiCaL archive header")
        for member in tar:
            parts = Path(member.name).parts
            if not parts or parts[0] != prefix or ".." in parts:
                raise RuntimeError(f"unexpected archive path: {member.name}")
            # The upstream archive contains one relative symlink, src/configure.
            if member.issym() and parts[1:] == ("src", "configure") and member.linkname == "../configure":
                continue
            if not (member.isdir() or member.isfile()):
                raise RuntimeError(f"unexpected archive entry: {member.name}")
    subprocess.run(["tar", "-xf", str(archive), "--strip-components=1", "-C", str(src)], check=True)
    print(f"CaDiCaL archive commit {COMMIT}", flush=True)


def build_proof_tools(build, repo, archive):
    src = build / "cadical"
    src.mkdir()
    if archive:
        extract_pinned_archive(archive, src)
    else:
        export_git_tree(build, src, repo)
    source_version = (src / "VERSION").read_text().strip()
    print(f"CaDiCaL VERSION={source_version}", flush=True)
    if source_version != "3.0.1":
        raise RuntimeError("unexpected source version before configure")
    # An exported tree has no .git. Do not inherit the enclosing review project's ID.
    build_env = dict(os.environ, GIT_CEILING_DIRECTORIES=str(build))
    with (build / "cadical-build.log").open("xb") as log:
        for command in (["./configure"], ["make", "-j1"]):
            print("CaDiCaL build:", " ".join(command), flush=True)
            subprocess.run(command, cwd=src, stdout=log, stderr=subprocess.STDOUT, env=build_env, check=True)
    solver = src / "build/cadical"
    version = subprocess.check_output([solver, "--version"], text=True).strip()
    if version != "3.0.1":
        raise RuntimeError(f"unexpected CaDiCaL version: {version}")
    print(f"CaDiCaL --version: {version}", flush=True)
    subprocess.run(["cc", "-O2", "-o", "lrat-check", "tools-src/drat-trim/lrat-check.c"],
                   cwd=build, check=True)
    cake = build / "tools-src/cake"
    subprocess.run(["make", "-j1"], cwd=cake, check=True)
    return solver, build / "lrat-check", cake / "cake_lpr"


def generate(idx, configs, build, out):
    core, cnf_sha, _ = CASES[idx]
    with configs.open("rb") as f:
        f.seek(10 * idx)
        row = struct.unpack("<5H", f.read(10))
    if row[0] != core:
        raise RuntimeError(f"{idx}: expected core X{core}, read {row}")
    print(f"idx={idx} core=X{core} side_rows={row[1:]} K=9 SB=1 level=7", flush=True)
    cnf = out / f"{idx}.cnf"
    with cnf.open("xb") as dst:
        subprocess.run([build / "r7cnf", build / "cores_e85.g6", configs, str(idx),
                        "9", "1", "7"], stdout=dst, check=True)
    if not compare(cnf, cnf_sha):
        raise RuntimeError(f"{idx}: CNF differs from the production ledger")


def verdict(cmd, log, expected_rc, expected_line, timeout):
    # Keep all diagnostics, and require the verdict on stdout as in production.
    with log.open("xb") as stdout, log.with_suffix(".err").open("xb") as stderr:
        try:
            proc = subprocess.run(cmd, stdout=stdout, stderr=stderr, timeout=timeout)
        except subprocess.TimeoutExpired:
            print(f"{log.stem}: TIMEOUT", flush=True)
            return False
    lines = log.read_bytes().splitlines()
    present = expected_line.encode("ascii") in lines
    print(f"{log.stem}: {expected_line if present else 'REFUSED'} (exit {proc.returncode})",
          flush=True)
    return proc.returncode == expected_rc and present


def check_proof(idx, out, tools):
    solver, lrat, cake = tools
    cnf, proof = out / f"{idx}.cnf", out / f"{idx}.lrat"
    if not verdict([solver, "-q", "-t", "300", "--lrat", "--binary=false", cnf, proof],
                   out / f"{idx}.cadical.log", 20, "s UNSATISFIABLE", 360):
        return False
    same = compare(proof, CASES[idx][2])
    first = verdict([lrat, cnf, proof], out / f"{idx}.lrat-check.log", 0, "c VERIFIED", 300)
    second = verdict([cake, cnf, proof], out / f"{idx}.cake_lpr.log", 0, "s VERIFIED UNSAT", 300)
    print(f"{idx} both_checkers={'PASS' if first and second else 'FAIL'} "
          f"production_proof_bytes={'MATCH' if same else 'DIFFER'}", flush=True)
    return first and second


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("reveal", type=Path, help="public corpus/r310-c35-r7/r7/reveal folder")
    parser.add_argument("out", type=Path, help="new output directory")
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument("--cnf-only", action="store_true", help="only build r7cnf and match both CNFs")
    mode.add_argument("--cadical-repo", type=Path, help="full offline replay from a local Git mirror")
    mode.add_argument("--cadical-archive", type=Path, help="full offline replay from the pinned codeload tar.gz")
    mode.add_argument("--fetch-cadical", action="store_true", help="full replay, fetch the public upstream")
    args = parser.parse_args()
    if sys.byteorder != "little":
        parser.error("the pinned generator reads native little-endian 16-bit records")
    bundle = args.reveal.resolve() / BUNDLE
    configs = args.reveal.resolve() / CONFIGS
    if not compare(bundle, BUNDLE_SHA) or not compare(configs, CONFIGS_SHA):
        raise RuntimeError("public input hash mismatch")
    out = args.out.resolve()
    out.mkdir()  # A previous run (including a partial one) retains its evidence.
    build = out / "build"
    build.mkdir()
    os.environ["TMPDIR"] = str(build)
    os.environ["LC_ALL"] = "C"
    os.environ["CLANG_MODULE_CACHE_PATH"] = str(build / "clang-cache")
    prepare_generator(bundle, build, not args.cnf_only)
    if not args.cnf_only:
        tools = build_proof_tools(build, args.cadical_repo, args.cadical_archive)
        for binary in (build / "r7cnf", *tools):
            print(f"built {binary.name} sha256={digest(binary)}", flush=True)
    for idx in CASES:
        generate(idx, configs, build, out)
    if args.cnf_only:
        print("CNF-only run complete. Solver and checkers skipped.", flush=True)
        return 0
    results = [check_proof(idx, out, tools) for idx in CASES]
    return 0 if all(results) else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (OSError, RuntimeError, subprocess.SubprocessError, tarfile.TarError) as err:
        sys.exit(f"regen: {err}")
